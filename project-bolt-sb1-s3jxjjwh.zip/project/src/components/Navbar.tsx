import React, { useState, useEffect } from 'react';
import { Leaf, Menu, X, Moon, Sun } from 'lucide-react';

export default function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(() => {
    const savedMode = localStorage.getItem('darkMode');
    return savedMode ? JSON.parse(savedMode) : false;
  });

  useEffect(() => {
    localStorage.setItem('darkMode', JSON.stringify(darkMode));
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <nav className="bg-green-700 dark:bg-gray-900 fixed w-full z-50 transition-colors duration-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Leaf className="h-8 w-8 text-white" />
            <span className="ml-2 text-white font-bold text-xl">EcoGrow</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-4">
            <div className="flex items-baseline space-x-4">
              <a href="#home" className="text-white hover:bg-green-600 dark:hover:bg-gray-700 px-3 py-2 rounded-md">Home</a>
              <a href="#services" className="text-white hover:bg-green-600 dark:hover:bg-gray-700 px-3 py-2 rounded-md">Services</a>
              <a href="#about" className="text-white hover:bg-green-600 dark:hover:bg-gray-700 px-3 py-2 rounded-md">About</a>
              <a href="#contact" className="text-white hover:bg-green-600 dark:hover:bg-gray-700 px-3 py-2 rounded-md">Contact</a>
            </div>
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="text-white p-2 rounded-md hover:bg-green-600 dark:hover:bg-gray-700 transition-colors duration-200"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
          </div>
          
          <div className="md:hidden flex items-center space-x-2">
            <button
              onClick={() => setDarkMode(!darkMode)}
              className="text-white p-2 rounded-md hover:bg-green-600 dark:hover:bg-gray-700"
              aria-label="Toggle dark mode"
            >
              {darkMode ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </button>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="text-white hover:bg-green-600 dark:hover:bg-gray-700 p-2 rounded-md"
            >
              {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {isMenuOpen && (
        <div className="md:hidden">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3 bg-green-700 dark:bg-gray-900">
            <a href="#home" className="text-white block px-3 py-2 rounded-md hover:bg-green-600 dark:hover:bg-gray-700">Home</a>
            <a href="#services" className="text-white block px-3 py-2 rounded-md hover:bg-green-600 dark:hover:bg-gray-700">Services</a>
            <a href="#about" className="text-white block px-3 py-2 rounded-md hover:bg-green-600 dark:hover:bg-gray-700">About</a>
            <a href="#contact" className="text-white block px-3 py-2 rounded-md hover:bg-green-600 dark:hover:bg-gray-700">Contact</a>
          </div>
        </div>
      )}
    </nav>
  );
}