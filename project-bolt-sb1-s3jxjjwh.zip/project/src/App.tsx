import React from 'react';
import { Plane as Plant, Sprout, Users, TreePine, Phone } from 'lucide-react';
import Navbar from './components/Navbar';
import ContactForm from './components/ContactForm';

function App() {
  return (
    <div className="min-h-screen bg-white dark:bg-gray-900 transition-colors duration-200">
      <Navbar />
      
      {/* Hero Section */}
      <section id="home" className="pt-20 bg-gradient-to-b from-green-700 to-green-500 dark:from-gray-800 dark:to-gray-700 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-32">
          <div className="text-center">
            <h1 className="text-4xl md:text-6xl font-bold mb-6">Sustainable Agriculture for a Better Tomorrow</h1>
            <p className="text-xl mb-8">Innovative solutions for environmental conservation and sustainable farming</p>
            <a href="#contact" className="bg-white text-green-700 dark:bg-gray-200 dark:text-gray-800 px-8 py-3 rounded-full font-semibold hover:bg-gray-100 dark:hover:bg-gray-300 transition duration-300">
              Get Started
            </a>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">Our Services</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="p-6 border dark:border-gray-700 rounded-lg hover:shadow-lg transition duration-300 dark:bg-gray-800">
              <Plant className="h-12 w-12 text-green-600 dark:text-green-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Sustainable Farming</h3>
              <p className="text-gray-600 dark:text-gray-300">Implementing eco-friendly farming practices for better yields and environmental protection.</p>
            </div>
            <div className="p-6 border dark:border-gray-700 rounded-lg hover:shadow-lg transition duration-300 dark:bg-gray-800">
              <Sprout className="h-12 w-12 text-green-600 dark:text-green-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Organic Solutions</h3>
              <p className="text-gray-600 dark:text-gray-300">Natural and organic approaches to pest control and soil enhancement.</p>
            </div>
            <div className="p-6 border dark:border-gray-700 rounded-lg hover:shadow-lg transition duration-300 dark:bg-gray-800">
              <TreePine className="h-12 w-12 text-green-600 dark:text-green-400 mb-4" />
              <h3 className="text-xl font-semibold mb-2 dark:text-white">Environmental Conservation</h3>
              <p className="text-gray-600 dark:text-gray-300">Protecting biodiversity and natural resources through sustainable practices.</p>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-gray-50 dark:bg-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1500651230702-0e2d8a49d4ad"
                alt="Sustainable farming"
                className="rounded-lg shadow-lg"
              />
            </div>
            <div>
              <h2 className="text-3xl font-bold mb-6 dark:text-white">About Us</h2>
              <p className="text-gray-600 dark:text-gray-300 mb-6">
                We are dedicated to promoting sustainable agriculture and environmental conservation through innovative solutions and expert guidance. Our team of professionals works tirelessly to help farmers and organizations implement eco-friendly practices.
              </p>
              <div className="flex items-center space-x-4">
                <Users className="h-6 w-6 text-green-600 dark:text-green-400" />
                <span className="text-lg font-semibold dark:text-white">Expert Team of Agricultural Specialists</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20 dark:bg-gray-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold mb-4 dark:text-white">Contact Us</h2>
            <p className="text-gray-600 dark:text-gray-300">Get in touch with us for any inquiries or consultation</p>
          </div>
          <div className="grid md:grid-cols-2 gap-12">
            <div className="bg-gray-50 dark:bg-gray-800 p-8 rounded-lg">
              <h3 className="text-xl font-semibold mb-4 dark:text-white">Contact Information</h3>
              <div className="space-y-4">
                <div className="flex items-center space-x-4">
                  <Phone className="h-5 w-5 text-green-600 dark:text-green-400" />
                  <span className="dark:text-gray-300">+1 (555) 123-4567</span>
                </div>
                <div className="flex items-center space-x-4">
                  <svg className="h-5 w-5 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                  </svg>
                  <span className="dark:text-gray-300">contact@ecogrow.com</span>
                </div>
                <div className="flex items-center space-x-4">
                  <svg className="h-5 w-5 text-green-600 dark:text-green-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                  </svg>
                  <span className="dark:text-gray-300">123 Eco Street, Green City, EC 12345</span>
                </div>
              </div>
            </div>
            <ContactForm />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-green-700 dark:bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <h4 className="text-lg font-semibold mb-4">EcoGrow</h4>
              <p className="text-sm">Sustainable solutions for a greener future</p>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2">
                <li><a href="#home" className="hover:text-gray-300">Home</a></li>
                <li><a href="#services" className="hover:text-gray-300">Services</a></li>
                <li><a href="#about" className="hover:text-gray-300">About</a></li>
                <li><a href="#contact" className="hover:text-gray-300">Contact</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-lg font-semibold mb-4">Follow Us</h4>
              <div className="flex space-x-4">
                <a href="#" className="hover:text-gray-300">Twitter</a>
                <a href="#" className="hover:text-gray-300">LinkedIn</a>
                <a href="#" className="hover:text-gray-300">Facebook</a>
              </div>
            </div>
          </div>
          <div className="mt-8 pt-8 border-t border-green-600 dark:border-gray-700 text-center">
            <p>&copy; {new Date().getFullYear()} EcoGrow. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;